# -*- coding: utf-8 -*-
'''
    EzScrapers Project
'''

import requests,re
from cocoscrapers.modules import source_utils
class source:
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True
    def __init__(self):
        self.language = ['en']
    def sources(self, data, hostDict):
        sources = []
        if not data: return sources
        append = sources.append
        year = data['year']
        imdb=data['imdb']
        aliases = data['aliases']

        if 'tvshowtitle' in data:
            self.hdlr = 'S%02d' % (int(data['season']))
        x=requests.get('https://pastebin.com/raw/YWR3ND0v').content.decode('utf-8')#().decode('utf-8')
        regex='imdb:"(.+?)" info:"(.+?)" size:"(.+?)" url:"(.+?)"'
        m=re.compile(regex,re.DOTALL).findall(x)
        
        for id,info,size,url in m:
            
            if id in imdb:
                if 'tvshowtitle' in data:
                    optional_separators = r'[\s._\-x+,&:]{0,2}' # 0-2 occurrences

                    regex_pattern = re.compile(r'S[e]?(?:ason)?' + optional_separators + '(?P<season_number>\d{1,2})'  , re.IGNORECASE)
                    match = regex_pattern.search(info)
                    if match:
                        extracted_season_number = match.group('season_number').zfill(2)
                        if extracted_season_number not in self.hdlr:
                         continue
                try:
                     o_size=size
                     file_size=float(o_size.replace('GB','').replace('MB','').replace(",",'').strip())
                     if 'MB' in o_size:
                       file_size=file_size/1000
                except Exception as e:
                    file_size=0
                quality=info
                if 'https://' in url:
                    host='audaciousdefaulthouse.com'
                    append({'provider': 'apropo', 'source': host,'seeders': 0,'name': info, 'name_info': info, 'quality': quality, 'language': 'en', 'url': url,
                                    'info': info, 'direct': False, 'debridonly': True, 'size': file_size})
                else:
                    hash = re.search(r'btih:(.*?)(?:&|$)', url, re.I).group(1)
                    append({'provider': 'apropo', 'source': 'torrent','seeders': 0, 'hash': hash ,'name': info, 'name_info': info, 'quality': quality, 'language': 'en', 'url': url,
                                    'info': info, 'direct': False, 'debridonly': True, 'size': file_size})


        return sources